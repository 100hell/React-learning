import React, { useContext } from "react";
import { ChakraProvider, Container, Heading } from "@chakra-ui/react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import AuthPage from "./components/AuthPage";

const App = () => {
  // const { user } = useContext(AuthContext);

  return (
    <ChakraProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="*" element={<AuthPage />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ChakraProvider>
  );
};

export default App;
