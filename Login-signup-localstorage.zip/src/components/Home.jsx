import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { Container, Heading } from "@chakra-ui/react";
import { Circles } from "react-loader-spinner";

const Home = () => {
  const { user, setUser } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 3000);
  }, []);

  return (
    <>
      {loading ? (
        <Circles
          height="80"
          width="80"
          color="green"
          ariaLabel="circles-loading"
          wrapperStyle={{}}
          wrapperClass=""
          visible={true}
        />
      ) : (
        <Container maxW="container.md" mt={8}>
          <Heading mb={4}>Welcome, {user.username}</Heading>
          <button onClick={handleLogout}>Logout</button>
        </Container>
      )}
    </>
  );
};

export default Home;
